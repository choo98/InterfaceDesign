/*jslint white:true*/
/*jslint evil:true*/
/*global angular*/

var app = angular.module("myApp", []);

app.controller("myCtrl", function ($scope) {
    "use strict";

    $scope.exploreProduct1 = [{
        img: "image/explorecases.png",
        name: "Cases"
        }, {
        img: "image/exploreKeyboards.png",
        name: "Keyboards"
        }, {
        img: "image/exploremouse.png",
        name: "Mice"
        }, {
        img: "image/exploreheadset.png",
        name: "Headsets"
        }, {
        img: "image/explorefans.png",
        name: "Fans"

    }];
    $scope.exploreProduct2 = [{
        img: "image/exploremousepad.png",
        name: "Mouse Pads"
        }, {
        img: "image/exploreram.png",
        name: "Memory"
        }, {
        img: "image/exploreps.png",
        name: "Power Supply"
        }, {
        img: "image/explorecooling.png",
        name: "Cooling"
        }, {
        img: "image/explorepc.png",
        name: "Gaming PC"

        }];
    $scope.exploreProduct3 = [{
        img: "image/explorepc.png",
        name: "Gaming PC"
        }, {
        img: "image/explorechair.png",
        name: "Gaming chair"
        }, {
        img: "image/explorelb.png",
        name: "Lapboard"
        }, {
        img: "image/explorestorage.png",
        name: "Storage"
        }, {
        img: "image/exploreicue.png",
        name: "ICUE"

        }];
    /*product highlight 1 */
    $scope.highlight1Name = "IRONCLAW RGB WIRELESS GAMING MOUSE";
    $scope.highlight1Img = "image/ironclaw.jpg";

    /*product highlight 2 */
    $scope.highlight2Name = "MM350 CHAMPION SERIES X-LARGE";
    $scope.highlight2Desc = "ANTI-FRAY CLOTH GAMING MOUSE PAD";
    $scope.highlight2Img = "image/mm350.png";

    /*product highlight 3*/
    $scope.highlight3Name = "K68 RGB";
    $scope.highlight3Desc = "SPILL RESISTANT GAMING KEYBOARD";
    $scope.highlight3Img = "image/k68.jpg";

    /*product highlight 4*/
    $scope.highlight4Name = "RM750X";
    $scope.highlight4Desc = "POWER SUPPLY";
    $scope.highlight4Img = "image/rm750.jpg";

    /*product highlight 5*/
    $scope.highlight5Name = "K83 WIRELESS";
    $scope.highlight5Desc = "ENTERTAINMENT KEYBOARD";
    $scope.highlight5Img = "image/k83.jpg";

    /*product highlight 6*/
    $scope.highlight6Name = "CRYSTAL SERIES 680X RGB";
    $scope.highlight6Desc = "TEMPERED GLASS SMART CASE";
    $scope.highlight6Img = "image/crystal680x.jpg";

    /*product highlight 7*/
    $scope.highlight7Name = "HS70 WIRELESS SE";
    $scope.highlight7Desc = "GAMING HEADSET";
    $scope.highlight7Img = "image/hs70.jpg";

    /*product highlight 8*/
    $scope.highlight8Name = "DOMINATOR PLATINUM RGB";
    $scope.highlight8Desc = "PREMIUM DDR4 MEMORY";
    $scope.highlight8Img = "image/dominator.jpg";

    /*hot products*/
    $scope.hotproductsName = "Hot New Products";
    $scope.hotproductsDesc = "LEARN MORE ABOUT OUR LATEST PRODUCTS >";
    $scope.hotproductsImg = "image/hotproducts.jpg";

    /*Corsair Esports*/
    $scope.esportsName = "CORSAIR Esports";
    $scope.esportsDesc = "LEARN MORE >";
    $scope.esportsImg = "image/corsairesports.jpg";

    /*Corsair PC building*/
    $scope.diyName = "How-to DIY";
    $scope.diyDesc = "FIRST TIME BUILDING A SYSTEM? FIND ADVICE,TOOLS AND GUIDES TO CREATE A STUNNING CUSTOM PC";
    $scope.diyImg = "image/pcbuilding.png";

    $scope.language = [{
        lname: "French"
        }, {
        lname: "German"
        }, {
        lname: "Mandarin"
        }, {
        lname: "Russian"
    }];

    $scope.location = [{
        lname: "Malaysia"
    }, {
        lname: "Germany"
        }, {
        lname: "Taiwan"
        }, {
        lname: "Russia"
        }, {
        lname: "France"
    }];

    $scope.support = [{
        sname: "Downloads"
    }, {
        sname: "Customer Support"
        }, {
        sname: "FAQs"
        }, {
        sname: "Warranty"
        }, {
        sname: "RMA/Returns"
    }];

    $scope.shopping = [{
        sname: "Where To Buy"
    }, {
        sname: "Memory Finder"
    }];

    $scope.company = [{
            sname: "About CORSAIR"
    }, {
            sname: "Careers"
        },
        {
            sname: "Contact"
        }, {
            sname: "Press Room"

    }];
    
     $scope.community = [{
            sname: "Blog"
    }, {
            sname: "Forums"
        },
        {
            sname: "Builders Showcase"
        }, {
            sname: "How-To Guides"

    }];


});

app.directive("exploreproduct1", function () {
    "use strict";
    return {
        scope: true,
        replace: true,
        restrict: 'EA',
        link: function (scope, element, attributes) {
            scope.img = attributes.img;
            scope.name = attributes.name;
        },
        template: '<div class="col-md-2 col-md-push-1 col-xs-2 col-xs-push-1"><a href="#"><img data-ng-src={{img}} class="img-responsive"></a><br/><h5><b>{{name}}<b></h5>'
    };
});

app.directive("exploreproduct2", function () {
    "use strict";
    return {
        scope: true,
        replace: true,
        restrict: 'E',
        link: function (scope, element, attributes) {
            scope.img = attributes.img;
            scope.name = attributes.name;
        },
        template: '<div class="col-md-2 col-md-push-1 col-xs-2 col-xs-push-1"><a href="#"><img data-ng-src={{img}} class="img-responsive"></a><br/><h5><b>{{name}}<b></h5></div>'
    };
});

app.directive("exploreproduct3", function () {
    "use strict";
    return {
        scope: true,
        replace: true,
        restrict: 'E',
        link: function (scope, element, attributes) {
            scope.img = attributes.img;
            scope.name = attributes.name;
        },
        template: '<div class="col-md-2 col-md-push-1 col-xs-2 col-xs-push-1"><a href="#"><img data-ng-src={{img}} class="img-responsive"></a><br/><h5><b>{{name}}<b></h5></div>'
    };

});

app.directive("producthighlight1", function () {
    "use strict";
    return {
        scope: true,
        replace: true,
        restrict: 'EA',
        link: function (scope, element, attributes) {
            scope.img = attributes.img;
        },
        template: '<img data-ng-src={{img}} class="img-responsive ironclaw">'
    };

});

app.directive("producthighlight2", function () {
    "use strict";
    return {
        scope: true,
        replace: true,
        restrict: 'EA',
        link: function (scope, element, attributes) {
            scope.img = attributes.img;
        },
        template: '<img data-ng-src={{img}} class="img-responsive mm350">'
    };

});

app.directive("producthighlight3", function () {
    "use strict";
    return {
        scope: true,
        replace: true,
        restrict: 'EA',
        link: function (scope, element, attributes) {
            scope.img = attributes.img;
        },
        template: '<img data-ng-src={{img}} class="img-responsive k68">'
    };

});

app.directive("producthighlight4", function () {
    "use strict";
    return {
        scope: true,
        replace: true,
        restrict: 'EA',
        link: function (scope, element, attributes) {
            scope.img = attributes.img;
        },
        template: '<img data-ng-src={{img}} class="img-responsive rm750">'
    };

});

app.directive("producthighlight5", function () {
    "use strict";
    return {
        scope: true,
        replace: true,
        restrict: 'EA',
        link: function (scope, element, attributes) {
            scope.img = attributes.img;
        },
        template: '<img data-ng-src={{img}} class="img-responsive k83">'
    };

});

app.directive("producthighlight6", function () {
    "use strict";
    return {
        scope: true,
        replace: true,
        restrict: 'EA',
        link: function (scope, element, attributes) {
            scope.img = attributes.img;
        },
        template: '<img data-ng-src={{img}} class="img-responsive c680x">'
    };

});

app.directive("producthighlight7", function () {
    "use strict";
    return {
        scope: true,
        replace: true,
        restrict: 'EA',
        link: function (scope, element, attributes) {
            scope.img = attributes.img;
        },
        template: '<img data-ng-src={{img}} class="img-responsive hs70">'
    };

});

app.directive("producthighlight8", function () {
    "use strict";
    return {
        scope: true,
        replace: true,
        restrict: 'EA',
        link: function (scope, element, attributes) {
            scope.img = attributes.img;
        },
        template: '<img data-ng-src={{img}} class="img-responsive dominator">'
    };

});

app.directive("hotproducts", function () {
    "use strict";
    return {
        scope: true,
        replace: true,
        restrict: 'EA',
        link: function (scope, element, attributes) {
            scope.img = attributes.img;
        },
        template: '<img data-ng-src={{img}} class="img-responsive hotcorsair">'
        /* image taken from http://www.teamopenoffice.org/topk/corsair-wallpaper/ */
    };

});

app.directive("corsairesports", function () {
    "use strict";
    return {
        scope: true,
        replace: true,
        restrict: 'EA',
        link: function (scope, element, attributes) {
            scope.img = attributes.img;
        },
        template: '<img data-ng-src={{img}} class="img-responsive esports">'
        /* image taken from http://www.teamopenoffice.org/topk/corsair-wallpaper/ */
    };

});

app.directive("corsairdiy", function () {
    "use strict";
    return {
        scope: true,
        replace: true,
        restrict: 'EA',
        link: function (scope, element, attributes) {
            scope.img = attributes.img;
        },
        template: '<img data-ng-src={{img}} class="img-responsive diy">'
        /* image taken from http://www.teamopenoffice.org/topk/corsair-wallpaper/ */
    };

});

<!DOCTYPE html>

<!-- data-ng-app="pigeon-table" in the html is essential to inject ngPigeon-table into the webpage-->
<html lang="en" data-ng-app="pigeon-table" data-ng-app="pigeon-chart">

<head>
    <title>Example</title>
    <!-- The includes.php file is required to include all necessary dependencies-->
    <?php
		include "pigeon-table/php/includes.php"
	?>

</head>

<body>

    <div class="container">
        <!-- View Data in table form -->
        <pigeon-table query="SELECT birthcountry, gender, count(*) 'TotalActor'
FROM actor
GROUP BY birthcountry, gender

" editable="true" control="true"></pigeon-table>

        <pigeon-table query="Select * from casting" editable="true" control="true"></pigeon-table>
    </div>

</body>

</html>

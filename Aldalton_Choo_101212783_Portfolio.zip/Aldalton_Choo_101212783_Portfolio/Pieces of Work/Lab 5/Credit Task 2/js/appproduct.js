/*global angular*/
var app = angular.module("myApp", []);

app.directive('product', function () {
    "use strict";
    return {
        scope: true,
        replace: true,
        restrict: 'E',
        link: function (scope, element, attributes) {
            scope.model = attributes.model;
            scope.price = attributes.price;
        },

        template: '<div class="col-md-3 myBox"><h4>{{model}}</h4><p><b>Price:</b> RM {{price}}</p>'

    };
});

/*global angular*/
/* reference for logic: https://stackoverflow.com/questions/9083037/convert-a-number-into-a-roman-numeral-in-javascript */

var app = angular.module('myApp', []);

//Custom Filter Implementation
app.filter("num2Roman", function () {
    "use strict";
    return function (myNum) {

        var rNumber = "",
            i,
            rInteger = [90, 50, 40, 10, 9, 5, 4, 1],
            rSymbol = ["XC", "L", "XL", "X", "IX", "V", "IV", "I"];

        for (i = 0; i < rSymbol.length; i += 1) {
            while (myNum >= rInteger[i]) {
                rNumber += rSymbol[i];
                myNum -= rInteger[i];
            }
        }
        return rNumber;

    };
});

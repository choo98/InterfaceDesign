/*jslint white:true */
/*jslint evil:true */
/*global angular */

var app = angular.module("statApp", []);
app.controller("myStat", function ($scope) {
    "use strict";
    
    $scope.newPost =[];
    
    $scope.submitStatus = function(status){
      $scope.newPost.push(status);  
    };
    
    $scope.deleteStatus = function(index){
        $scope.newPost.splice(index, 1);
    };

});

/*jslint white:true */
/*global angular */

var app = angular.module("myApp", []);
app.controller("myCtrl", function ($scope) {
        "use strict";

        $scope.cAnswer = function () {
            $scope.nGap = $scope.rNumber - $scope.inputNumber;
        };
    
        $scope.nGame = function () {
            $scope.inputNumber = null;
            $scope.rNumber = Math.floor(Math.random() * 100 + 1);
            $scope.nGap = null;
            $scope.sAnswer = false;
        };

        $scope.gUp = function () {
            $scope.rNumber = Math.floor(Math.random() * 100 + 1);
            $scope.sAnswer = true;
        };
    
    $scope.nGame();

    }

);
